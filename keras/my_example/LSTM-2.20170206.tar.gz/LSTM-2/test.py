#encoding:utf-8
import pickle
f=open('dict','rb')
x=pickle.load(f)
print x
